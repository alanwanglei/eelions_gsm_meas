This directory contains example Asterisk configuration files for the OpenBTS Asterisk server.
It also includes a set of network error messages, English only so far.

